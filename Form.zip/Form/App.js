import './App.css';
import Toggls from './Components/Toggle/Toggls';
import Form from './Components/multipleForm/Form';

function App() {
  return (
    <div className="App">
      {/* <Toggls /> */}
      <Form />
    </div>
  );
}

export default App;
